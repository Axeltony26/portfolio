import React from 'react'
import "./Contact.css"
import { useLocation, useParams } from 'react-router-dom'
function Contact() {
  return (
    <div className='contact'>Contacter-nous<br></br>
        
    </div>
  )
}

export default Contact